# MIT 805 Big Data Semester Project — NYC HVFHV Trip Records

Large-scale analysis and distributed processing of the **NYC TLC High-Volume
For-Hire Vehicle (HVFHV)** trip records (Uber/Lyft ride-hail), using **PySpark**.

**Group [NN]:** [Member 1] ([student no.]) · [Member 2] ([student no.])

## Dataset (not stored in this repo)
- **Source:** NYC Taxi & Limousine Commission — TLC Trip Record Data
  <https://www.nyc.gov/site/tlc/about/tlc-trip-record-data.page>
- **Files:** `fhvhv_tripdata_YYYY-MM.parquet` from
  `https://d37ci6vzurychx.cloudfront.net/trip-data/`
- **Licence:** NYC Open Data (NYC Terms of Use) — no restrictions on use.
- The data is **not committed** (large + redistribution discouraged). See
  [`data/README.md`](data/README.md) for exact retrieval instructions.

## Dataset scales (measured)
| Level | Files | Size | Coverage |
|------|------:|-----:|----------|
| Raw (full corpus) | 89 | 37.58 GB | Feb 2019 – Jun 2026 |
| Working | 26 | 12.00 GB | May 2024 – Jun 2026 |
| Processing (PySpark) | 7 | 3.36 GB | Dec 2025 – Jun 2026 |

## Repository structure
```
project/
├── README.md            # this file
├── requirements.txt     # Python dependencies
├── data/                # data NOT stored here — see data/README.md
│   └── README.md
├── notebooks/           # Colab / Jupyter notebooks (Part 1 EDA, Part 2 PySpark)
├── src/                 # reusable Python modules
├── output/              # generated tables (CSV)
├── figures/             # generated plots (PNG)
└── report/              # LaTeX/PDF report
```

## Reproducing the analysis
1. `pip install -r requirements.txt`
2. Follow [`data/README.md`](data/README.md) to fetch the parquet files.
3. Run `notebooks/MIT_805_Part1_HVFHV.ipynb` top-to-bottom
   (Runtime → Run all). Figures are written to `figures/`, tables to `output/`.
4. Part 2 PySpark analysis: `notebooks/` (see Part 2 notebook / `src/`).

## Team & contribution
Both members contribute via commits; GitHub commit history documents individual
contribution as required by the brief.

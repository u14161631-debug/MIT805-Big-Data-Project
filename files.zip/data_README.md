# Data — retrieval instructions

The dataset is **not stored in this repository** (it is tens of GB and NYC's
terms discourage redistribution). Reproduce it directly from the official source.

## Source
NYC TLC HVFHV trip records — monthly Apache Parquet files:
```
https://d37ci6vzurychx.cloudfront.net/trip-data/fhvhv_tripdata_YYYY-MM.parquet
```
Landing page: https://www.nyc.gov/site/tlc/about/tlc-trip-record-data.page
Taxi-zone lookup: https://d37ci6vzurychx.cloudfront.net/misc/taxi_zone_lookup.csv

## Dataset scales used
- **Raw** = full public corpus, Feb 2019 – Jun 2026 (89 files, 37.58 GB).
- **Working** = most-recent 26 months (12.00 GB).
- **Processing** = most-recent 7 months, Dec 2025 – Jun 2026 (3.36 GB) — PySpark.

## Download the processing set (example)
```bash
mkdir -p data/processing
for m in 2025-12 2026-01 2026-02 2026-03 2026-04 2026-05 2026-06; do
  wget -P data/processing \
    "https://d37ci6vzurychx.cloudfront.net/trip-data/fhvhv_tripdata_${m}.parquet"
done
```
The notebook can also read files directly over HTTPS without downloading
(`pd.read_parquet(url)` / Spark `read.parquet` on a local copy).

> Do not commit the `.parquet` files — `.gitignore` excludes them.
